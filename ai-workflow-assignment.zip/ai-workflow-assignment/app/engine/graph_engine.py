from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4
from enum import Enum


State = Dict[str, Any]
ToolFn = Callable[[State], State]


class RunStatus(str, Enum):
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class ToolRegistry:
    """
    Simple registry that holds named Python functions (tools).
    """

    def __init__(self) -> None:
        self._tools: Dict[str, ToolFn] = {}

    def register(self, name: str, fn: ToolFn) -> None:
        self._tools[name] = fn

    def get(self, name: str) -> ToolFn:
        if name not in self._tools:
            raise KeyError(f"Tool '{name}' is not registered.")
        return self._tools[name]

    def list_tools(self) -> List[str]:
        return list(self._tools.keys())


class Graph:
    """
    Graph structure:
    - nodes: mapping of node_name -> tool_name
    - edges: mapping of from_node -> to_node (or None)
    - start_node: name of the first node to run
    """

    def __init__(
        self,
        graph_id: str,
        nodes: Dict[str, str],
        edges: Dict[str, Optional[str]],
        start_node: str,
    ) -> None:
        if start_node not in nodes:
            raise ValueError("start_node must be one of the node names")

        self.graph_id = graph_id
        self.nodes = nodes
        self.edges = edges
        self.start_node = start_node


class Run:
    """
    Represents a single execution of a graph.
    """

    def __init__(self, run_id: str, graph: Graph, initial_state: State) -> None:
        self.run_id = run_id
        self.graph = graph
        self.current_node: Optional[str] = graph.start_node
        self.state: State = dict(initial_state)  # copy
        self.log: List[Dict[str, Any]] = []
        self.status: RunStatus = RunStatus.RUNNING
        self.error: Optional[str] = None

    def step(self, registry: ToolRegistry) -> None:
        if self.current_node is None or self.status != RunStatus.RUNNING:
            return

        node_name = self.current_node
        tool_name = self.graph.nodes[node_name]

        try:
            tool_fn = registry.get(tool_name)
        except KeyError as e:
            self.status = RunStatus.FAILED
            self.error = str(e)
            return

        # Call the tool; it can mutate and/or return state
        new_state = tool_fn(self.state) or self.state
        self.state = new_state

        # Record log snapshot
        self.log.append(
            {
                "node": node_name,
                "tool": tool_name,
                "state": dict(self.state),  # shallow copy for snapshot
            }
        )

        # Branching support: if tool sets "_next_node" in state, follow that
        next_node = self.state.pop("_next_node", None)
        if next_node is not None:
            # Explicit next node from tool
            self.current_node = next_node
        else:
            # Otherwise follow static edge
            self.current_node = self.graph.edges.get(node_name)

        # If we reached the end
        if self.current_node is None:
            self.status = RunStatus.COMPLETED

    def run_to_completion(
        self, registry: ToolRegistry, max_steps: int = 100
    ) -> State:
        steps = 0
        while self.status == RunStatus.RUNNING and steps < max_steps:
            self.step(registry)
            steps += 1

        if self.status == RunStatus.RUNNING:
            # safety stop
            self.status = RunStatus.FAILED
            self.error = f"Max steps ({max_steps}) exceeded - possible infinite loop"

        return self.state


class GraphEngine:
    """
    Holds all graphs and runs in memory.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry
        self.graphs: Dict[str, Graph] = {}
        self.runs: Dict[str, Run] = {}

    def create_graph(
        self,
        nodes: Dict[str, str],
        edges: Dict[str, Optional[str]],
        start_node: str,
        graph_id: Optional[str] = None,
    ) -> str:
        graph_id = graph_id or str(uuid4())
        graph = Graph(graph_id=graph_id, nodes=nodes, edges=edges, start_node=start_node)
        self.graphs[graph_id] = graph
        return graph_id

    def get_graph(self, graph_id: str) -> Graph:
        if graph_id not in self.graphs:
            raise KeyError(f"Graph '{graph_id}' not found.")
        return self.graphs[graph_id]

    def start_run(self, graph_id: str, initial_state: State) -> Run:
        graph = self.get_graph(graph_id)
        run_id = str(uuid4())
        run = Run(run_id, graph, initial_state)
        self.runs[run_id] = run
        # For this assignment, we run synchronously to completion
        run.run_to_completion(self.registry)
        return run

    def get_run(self, run_id: str) -> Run:
        if run_id not in self.runs:
            raise KeyError(f"Run '{run_id}' not found.")
        return self.runs[run_id]
