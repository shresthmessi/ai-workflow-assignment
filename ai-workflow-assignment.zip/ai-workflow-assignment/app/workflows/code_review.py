from typing import List, Dict, Any
from app.engine.graph_engine import ToolRegistry, State


# -------------------------------
# 1. Extract functions from code
# -------------------------------

def extract_functions_tool(state: State) -> State:
    """
    Very simple parser:
    Looks for lines starting with 'def ' and extracts function names.
    """
    code: str = state.get("code", "")
    functions: List[str] = []

    for line in code.splitlines():
        stripped = line.strip()
        if stripped.startswith("def "):
            # Example: def foo(x):
            name_part = stripped.split("def ", 1)[1]
            func_name = name_part.split("(", 1)[0].strip()
            functions.append(func_name)

    state["functions"] = functions
    return state


# -------------------------------
# 2. Check code complexity
# -------------------------------

def check_complexity_tool(state: State) -> State:
    """
    Fake complexity score based on:
    - number of functions
    - number of lines
    """
    code: str = state.get("code", "")
    functions: List[str] = state.get("functions", [])
    lines = [line for line in code.splitlines() if line.strip()]

    func_count = len(functions)
    line_count = len(lines)

    # Simple fake formula
    complexity = func_count * 2 + (line_count / 10.0)

    state["metrics"] = {
        "function_count": func_count,
        "line_count": line_count,
        "complexity_score": round(complexity, 2)
    }
    return state


# -------------------------------
# 3. Detect simple issues
# -------------------------------

def detect_issues_tool(state: State) -> State:
    """
    Detects:
    - TODO comments
    - Long files (more than 60 lines)
    """
    code: str = state.get("code", "")
    lines = code.splitlines()

    issues: List[str] = []

    if "TODO" in code:
        issues.append("Found TODO comment in the code.")

    non_empty = [ln for ln in lines if ln.strip()]
    if len(non_empty) > 60:
        issues.append("File too long; consider splitting into smaller modules.")

    state["issues"] = issues
    return state


# -------------------------------
# 4. Suggest improvements + Looping
# -------------------------------

def suggest_improvements_tool(state: State) -> State:
    """
    Suggests improvements and calculates a quality score.
    If quality_score < threshold → loops back to itself.
    """
    metrics: Dict[str, Any] = state.get("metrics", {})
    issues: List[str] = state.get("issues", [])
    complexity = metrics.get("complexity_score", 0)

    suggestions: List[str] = []

    if metrics.get("function_count", 0) == 0:
        suggestions.append("Add functions to organize the code.")

    if complexity > 15:
        suggestions.append("Complexity is high. Try breaking code into smaller parts.")
    else:
        suggestions.append("Complexity is acceptable.")

    for issue in issues:
        if "TODO" in issue:
            suggestions.append("Fix TODO comments before finalizing the code.")
        if "long" in issue:
            suggestions.append("Split long files to improve readability.")

    # Quality score: simple formula
    base_score = 5.0
    penalty_issues = 0.5 * len(issues)
    penalty_complexity = max(0, complexity - 10) * 0.1
    quality_score = max(0, base_score - penalty_issues - penalty_complexity)

    state["suggestions"] = suggestions
    state["quality_score"] = round(quality_score, 2)

    # Looping mechanism:
    threshold = state.get("quality_threshold", 4.0)

    if quality_score < threshold:
        # Loop back to same node
        state["_next_node"] = "suggest_improvements"

    return state


# --------------------------------------------
# Register all tools for use in the workflow
# --------------------------------------------

def register_code_review_tools(registry: ToolRegistry) -> None:
    registry.register("extract_functions", extract_functions_tool)
    registry.register("check_complexity", check_complexity_tool)
    registry.register("detect_issues", detect_issues_tool)
    registry.register("suggest_improvements", suggest_improvements_tool)
